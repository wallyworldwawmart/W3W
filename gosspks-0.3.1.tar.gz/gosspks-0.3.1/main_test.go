package main // import jdel.org/gosspks/main

import (
	"testing"
)

func TestDummy(t *testing.T) {
}
